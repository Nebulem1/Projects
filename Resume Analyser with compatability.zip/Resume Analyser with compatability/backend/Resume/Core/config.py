from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = None
    SECRET_KEY:str=None 
    ALGORITHM:str=None
    ACCESS_TOKEN_EXPIRE_MINUTES:int=15 
    google_key:str 
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True
setting=Settings()
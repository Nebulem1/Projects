from Services.Embedding import embeddings
from Services.LLM import llm
from Services.Splitter import spliting
from models.prompt import prompt_resume_analysis,prompt_compare_resume_jd ,prompt_job_compatibility
from langchain.document_loaders import UnstructuredURLLoader
from langchain_core.output_parsers import JsonOutputParser
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain.vectorstores import FAISS
import os 
import shutil
from sqlalchemy.orm import Session
from Schema.user import Vector

parser = JsonOutputParser()
def fetch_job_compatability(link: str,user_id:int,db:Session):
    loader = UnstructuredURLLoader(urls=[link])
    docs = loader.load() 
    split_docs = spliting.split_documents(docs)
    vectorstore_path = f"vectorstore/{user_id}"

    if os.path.exists(vectorstore_path):
         shutil.rmtree(vectorstore_path)
    vec=Vector(user_id=user_id,path=vectorstore_path)
    db.add(vec)
    db.commit()
    db.refresh(vec)
    vector = FAISS.from_documents(split_docs, embedding=embeddings)
    vector.save_local(vectorstore_path)
    del vector
    full_text = "\n".join(doc.page_content for doc in docs)
    job_compat = prompt_job_compatibility | llm | parser
    return job_compat.invoke({'page_data': full_text})
    
def analyse_resume(doc:str):
    chain_extract=prompt_resume_analysis | llm | parser
    return chain_extract.invoke( input={'resume':doc})

def check_compatability(job:dict,compatability:dict):
    compare=prompt_compare_resume_jd | llm | parser
    return compare.invoke(input={"resume":compatability,"jd":job})

def ask_qa(text: str, user_id: int, db: Session):
    user = db.query(Vector).filter(Vector.user_id == user_id).first()
    user_vector = FAISS.load_local(user.path, embeddings, allow_dangerous_deserialization=True)

    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    retrieval_chat = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=user_vector.as_retriever(),
        memory=memory
    )

    response = retrieval_chat.invoke({"question": text})
    return response["answer"]
from langchain.text_splitter import RecursiveCharacterTextSplitter

spliting=RecursiveCharacterTextSplitter(
     separators=['\n\n','\n','.']
    ,chunk_size=200
)
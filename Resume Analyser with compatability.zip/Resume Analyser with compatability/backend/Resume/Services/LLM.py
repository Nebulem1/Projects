from langchain_google_genai import ChatGoogleGenerativeAI
from Core.config import setting
import os 
os.environ["GOOGLE_API_KEY"]=setting.google_key
llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash")

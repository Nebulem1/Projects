from langchain.prompts import PromptTemplate

prompt_resume_analysis = PromptTemplate.from_template(
    """
You are a highly experienced career advisor.

Here is the content extracted from a candidate's resume:

--- RESUME ---
{resume}

--- INSTRUCTION ---
Analyze the candidate's resume and return insights in valid JSON format with these keys:

- `name`: Candidate's full name (if available)
- `total_experience`: Estimated total experience in years
- `skills`: List of technical and soft skills
- `projects`: Brief summary of key projects (if available)
- `education`: Highest degree or field of study
- `recommendations`: Suggestions to improve the resume (2-3 points)
- `suggestion`: Suggest most suitable job roles with high salary potential
- `invalid`: If the resume is incomplete/invalid, return `invalid` with suggestion to fix format

⚠️ Only return **valid JSON**. No additional explanation or formatting.
"""
)


prompt_job_compatibility = PromptTemplate.from_template(
        """
        ### SCRAPED TEXT FROM WEBSITE:
        {page_data}

        ### INSTRUCTION:
        The above text is from a job or career page.

        Your task is to extract all job openings in **valid JSON format** with the following keys:

        - `role`: Job title
        - `experience`: Required experience
        - `skills`: Required skills
        - `description`: Brief job description

        ⚠️ Only return valid JSON. No preamble, no explanation.
        """
)

prompt_compare_resume_jd = PromptTemplate.from_template(
    """
### RESUME:
{resume}

### JOB DESCRIPTION:
{jd}

Compare the resume with the job description and return:

- `match_score`: Percentage match (0–100)
- `missing_skills`: Skills the candidate lacks for the role
- `recommendation`: Advice for improving the match

⚠️ Output valid JSON only.
"""
)
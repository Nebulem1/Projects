from pydantic import BaseModel
from typing import Optional

class UserData(BaseModel):
    username:str 
    password:str

class UserOut(BaseModel):
    username:str
    id:int 

class UserQuestion(BaseModel):
    id:int 
    text:str 
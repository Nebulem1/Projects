from fastapi import APIRouter, UploadFile, File, Form,HTTPException,Depends
from DB.Database import get_db
from utils.LLM import fetch_job_compatability,analyse_resume,check_compatability,ask_qa
from langchain_community.document_loaders import PyMuPDFLoader
from models.models import UserQuestion
import tempfile
from sqlalchemy.orm import Session

router=APIRouter()
temp={}

@router.post("/analyse_resume")
async def resume(pdf: UploadFile = File(...)):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(await pdf.read())
            tmp_path = tmp.name

        loader = PyMuPDFLoader(tmp_path)
        data = loader.load()
        analysis = analyse_resume(data)
        temp["pdf"] = analysis
        return analysis

@router.post("/analyse_link/{user_id}")
async def job_compat(user_id: int,link:str = Form(None),db:Session=Depends(get_db)):
        job_compat = fetch_job_compatability(link=link, user_id=user_id,db=db)
        temp["link"] = job_compat
        return job_compat[0]
       

@router.get("/compat")
async def check_compat():
    if not temp.get("link") or not temp.get("pdf"):
        raise HTTPException(status_code=404,detail="Sufficient data not provided")
    return check_compatability(temp["link"],temp["pdf"])

@router.post("/qa")
async def ask_question(question:UserQuestion,db:Session=Depends(get_db)):
    return ask_qa(question.text,question.id,db)
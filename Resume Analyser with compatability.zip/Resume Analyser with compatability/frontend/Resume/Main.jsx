import React from 'react'
import Login from './Login'
import Signup from './Signup'
import DashBoard from './DashBoard'
import { BrowserRouter as BR ,Route,Routes} from 'react-router-dom'
import Pdf from './Pdf'
import LinkForm from './LinkForm'
import Compat from './Compat'
import Ai from './Ai'

const Main = () => {
  return (
    <div>
        <BR>
        <Routes>
         <Route path="/" element={<Login />}/>
         <Route path="/signup" element={<Signup />} />
         <Route path="/DashBoard" element={<DashBoard />} />
         <Route path="/qa" element={<Ai />} />
         <Route path="/compat" element={<Compat />} />
         <Route path="/pdf" element={<Pdf />} />
         <Route path="/link" element={<LinkForm />} />
        </Routes>    
        </BR>
    </div>
  )
}

export default Main

import { useState } from "react";
import api from "./Axios";
import { Link } from "react-router-dom";

const LinkForm = () => {
  const [link, setLink] = useState("");
  const [result, setResult] = useState(null);
  let user= JSON.parse(localStorage.getItem("user")).id
  const handleSubmit = async () => {
    if (!link) {
      alert("Please enter a job link");
      return;
    }
     
    const formData = new FormData();
    formData.append("link", link);

    try {
      const res = await api.post(`/analyse_link/${user}`, formData);
      setResult(res.data);
      console.log("Job Compatibility:", res.data);
    } catch (err) {
      console.error("Error:", err);
      alert("Something went wrong");
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Enter job link"
        value={link}
        onChange={(e) => setLink(e.target.value)}
      />
      <button onClick={handleSubmit}>Analyze Job Link</button>

      {result && (
        <div style={{ marginTop: "20px" }}>
          <h3>Job Analysis Result:</h3>
           <h4> Role : {result.role} </h4>
           <h4> Experience : {result.experience} </h4>
           {result.skills.length>0 && (
            <>
                 <h1> Skills Required </h1>
                    <ul>
                    {result.skills.map((data, index) => (
                        <li key={index}>{data}</li>
                    ))}
                    </ul>
            </>
        )}
           <h4> Description : {result.description} </h4>
        <Link to="/qa"> Ask QA if Link is given </Link>
        </div>
      )}
    </div>
  );
};

export default LinkForm;

// [
//   {
//     "role": "Retail Associate, SEAS - Nike Northfield",
//     "experience": "Not specified",
//     "skills": [
//       "Customer service",
//       "Product knowledge",
//       "Communication",
//       "Teamwork",
//       "Cash register operation",
//       "Shipping and receiving",
//       "Stocking",
//       "Visual merchandising"
//     ],
//     "description": "As a Nike Retail Associate, you’re the face of NIKE. Enjoy high-volume and a fast pace as your diverse experience and perspective helps guide customers in making the best decisions for them. You’ll work with your team to focus on customer service and get to the win the right way."
//   }
// ]
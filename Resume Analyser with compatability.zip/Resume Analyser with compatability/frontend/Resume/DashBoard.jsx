import React from 'react'
import { useEffect,useState } from 'react'
import api from './Axios'
import { Link,useNavigate } from 'react-router-dom'


const DashBoard = () => {
  return (
    <div>
           <h3> Smart Resume Analyser </h3>

           <Link to="/link"> Search Link </Link>
           <Link to="/pdf"> Analyse Resume </Link>
           <Link to="/compat"> Check Compatability </Link>
           
    </div>
  )
}

export default DashBoard

import api from './Axios'
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

const Login = () => {
  let [username, setUsername] = useState("")
  let [password, setPassword] = useState("")
  let navigate = useNavigate();

  let handleToken = async () => {
    try {
      let token = localStorage.getItem("token");
      if (token) {
        let response = await api.get("/users/me", {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        localStorage.setItem("user", JSON.stringify(response.data));
        navigate("/DashBoard");
      }
    } catch (err) {
      alert("Token invalid. Try logging in again.");
      localStorage.removeItem("token");
    }
  }

  let handleLogin = async () => {
    try {
      let token = await api.post("/token", {
        username,
        password,
      });

      if (token.data) {
        localStorage.setItem("token", token.data.access_token);
        await handleToken();
      }
    } catch (err) {
      alert("Login failed. Please check username or password.");
    }
  }

  return (
    <div>
      <label htmlFor="email">Enter Your Email</label>
      <input
        type="text"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />

      <label htmlFor="pass">Enter Your Password</label>
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

      <button onClick={handleLogin} disabled={!username || !password}>Sign In</button>
      <br />
      <Link to="/signup">New at our site? Signup</Link>
    </div>
  )
}

export default Login
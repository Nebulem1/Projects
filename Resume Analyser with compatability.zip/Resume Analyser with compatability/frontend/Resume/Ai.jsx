import React, { useState } from 'react'
import api from './Axios'

const Ai = () => {
  const [chatHist, setChatHist] = useState([]);
  const [chat, setChat] = useState("");

  const user = JSON.parse(localStorage.getItem("user"))?.id;

  const handleAi = async () => {
    if (chat.trim() === "") {
      alert("Please enter a valid query");
      return;
    }

    try {
      const res = await api.post("/qa", {
        id: user,
        text: chat
      });

      if (res.data) {
        const newChat = {
          user: chat,
          AI: res.data
        };
        setChatHist([...chatHist, newChat]);
        setChat(""); // clear input after ask
      }
    } catch (error) {
      console.error("Error calling AI:", error);
      alert("Failed to get response from AI.");
    }
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <label htmlFor="chat" className="block mb-2 font-medium">Ask Your Query</label>
      <div className="flex items-center gap-2 mb-4">
        <input
          type="text"
          id="chat"
          value={chat}
          onChange={(e) => setChat(e.target.value)}
          className="flex-1 border px-3 py-2 rounded"
          placeholder="Enter your question..."
        />
        <button
          onClick={handleAi}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Ask AI
        </button>
      </div>

      <section className="space-y-4">
        {chatHist.map((item, index) => (
          <div
            key={index}
            className="bg-gray-100 p-3 rounded border border-gray-300"
          >
            <p><strong>You:</strong> {item.user}</p>
            <p><strong>AI:</strong> {item.AI}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

export default Ai;

import { useState } from "react";
import api from "./Axios";

const Pdf = () => {
  const [file, setFile] = useState(null);
  const [analyse, setAnalyse] = useState({}); 
  const handleSubmit = async () => {
    if (!file) {
      alert("Please select a PDF file");
      return;
    }

    const formData = new FormData();
    formData.append("pdf", file);
    try {
      const res = await api.post(`/analyse_resume`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setAnalyse(res.data);
      console.log("Analysis: ", res.data);
    } catch (err) {
      console.error("Upload failed", err);
    }
  };

  return (
    <div>
      <input
        type="file"
        accept="application/pdf"
        onChange={(e) => {
          setFile(e.target.files[0]);
        }}
      />
      <button onClick={handleSubmit}>Submit</button>

     {analyse && analyse.invalid === null && (
        <div style={{ marginTop: "20px" }}>
            <h3>Resume Analysis Result:</h3>
            <h3>Name : {analyse.name}</h3>
            <h3>Total Experience : {analyse.total_experience} Years </h3>

            {analyse.skills.length > 0 && (
            <>
                <h2>Skills:</h2>
                <ul>
                {analyse.skills.map((data, index) => (
                    <li key={index}>{data}</li>
                ))}
                </ul>
            </>
            )}

            {analyse.projects.length > 0 && (
            <>
                <h2>Projects:</h2>
                <ul>
                {analyse.projects.map((data, index) => (
                    <li key={index}>{data}</li>
                ))}
                </ul>
            </>
            )}

            <h3> Education : {analyse.education} </h3>

            {analyse.recommendations.length > 0 && (
            <>
                <h2>Recommendations Improvement in Resume:</h2>
                <ul>
                {analyse.recommendations.map((data, index) => (
                    <li key={index}>{data}</li>
                ))}
                </ul>
            </>
            )}

              {analyse.suggestion.length > 0 && (
            <>
                <h2>Suggest Jobs :</h2>
                <ul>
                {analyse.suggestion.map((data, index) => (
                    <li key={index}>{data}</li>
                ))}
                </ul>
            </>
            )}
        </div>
        )}

      {analyse.invalid && (
        <>
   
                <ul>
                {analyse.recommendations.map((data, index) => (
                    <li key={index}>{data}</li>
                ))}
                </ul>
        </>
      )}
    </div>
  );
};

export default Pdf;

// {
//   "name": "Vidyadhar Jangir",
//   "total_experience": "15 years 4 months",
//   "skills": [
//     "Operations Management",
//     "Team Leadership (10 members)",
//     "Team Leadership (5 members)",
//     "Load Factor Analysis",
//     "Vehicle Scheduling",
//     "Loading & Unloading Operations",
//     "Capacity Utilization",
//     "DEPS Control",
//     "Cost Management (COST/QKM)",
//     "Vendor Evaluation",
//     "Inbound & Outbound Shipments Handling",
//     "Trip Hire Contracts",
//     "JIT Deliveries",
//     "Warehouse Activities",
//     "Customer Coordination",
//     "Problem Solving",
//     "Customer Satisfaction",
//     "Market Vehicle Deployment"
//   ],
//   "projects": [],
//   "education": "Bachelor of Arts",
//   "recommendations": [
//     "Quantify achievements with specific numbers and data to demonstrate impact.",
//     "Use action verbs to start bullet points in the responsibilities section to highlight accomplishments.",
//     "Consider adding a skills section to explicitly list technical and soft skills."
//   ],
//   "suggestion": [
//     "Operations Manager",
//     "Logistics Manager",
//     "Supply Chain Manager",
//     "Transit Center Manager"
//   ],
//   "invalid": null
// }
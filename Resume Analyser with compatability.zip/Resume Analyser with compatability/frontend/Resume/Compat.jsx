import React, { useState } from 'react';
import api from "./Axios";

let Compat=()=> {
  const [compatibility, setCompatibility] = useState(null);
  const [error, setError] = useState(null);

  const handleCheckCompatibility = async () => {
    try {
      const response = await api.get('/compat');
      setCompatibility(response.data);
      setError(null);
    } catch (err) {
      setCompatibility(null);
      setError(err.response?.data?.detail || 'An error occurred');
    }
  };

  return (
    <div className="p-4">
      <button 
        onClick={handleCheckCompatibility}
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
      >
        Check Resume vs JD Compatibility
      </button>

      {compatibility && (
        <div className="mt-4 p-4 bg-green-100 border border-green-300 rounded">
          <h2 className="font-semibold text-lg">Compatibility Result:</h2>
          <h3> Job Match :{compatibility.match_score} % </h3>
           
           {compatibility.missing_skills.length > 0 && (
            <>
                <h2>Missing Skills :</h2>
                <ul>
                {compatibility.missing_skills.map((data, index) => (
                    <li key={index}>{data}</li>
                ))}
                </ul>
            </>
            )}
            <h3> Recommendation : {compatibility.recommendation} </h3>
        </div>
      )}

      {error && (
        <div className="mt-4 p-4 bg-red-100 border border-red-300 rounded">
          <h2 className="font-semibold text-lg text-red-700">Error:</h2>
          <p>{error}</p>
        </div>
      )}
    </div>
  );
}

export default Compat;

// {
//   "match_score": 15,
//   "missing_skills": [
//     "Customer service",
//     "Enthusiasm for Nike products",
//     "Cash register operation",
//     "Shipping and receiving",
//     "Stocking products",
//     "Visual display creation"
//   ],
//   "recommendation": "While Vidyadhar has extensive experience in logistics and operations management, the Retail Associate role at Nike Northfield requires strong customer service skills and product knowledge. To improve the match, Vidyadhar should consider highlighting any experience he has interacting directly with customers, even if it's in a different context. He could also pursue training or certifications in customer service to demonstrate his commitment to developing these skills. Tailoring the resume to emphasize transferable skills like communication and problem-solving in a customer-facing setting would also be beneficial."
// }
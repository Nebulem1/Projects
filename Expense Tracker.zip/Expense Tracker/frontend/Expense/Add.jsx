import api from "./Axios"
import React from 'react'
import { useState } from 'react'
import { useNavigate } from "react-router-dom"

const Add = () => {
    
    let [amount,setAmount]=useState(0);
    let [category,setCategory]=useState("");
    let [description,setDescription]=useState("");
    let navigate=useNavigate()
    let handelSubmit =async ()=>{
        let id=JSON.parse(localStorage.getItem("user")).id
        let ob={
            amount,category,description
        }
        await api.post(`add_expenses/${id}`,ob)
         navigate("/DashBoard");
    }
  return (
    <div>
        Amount 
        <input type="number" onChange={(e)=>{
            setAmount(e.target.value)
        }} />         
        Category 
        <input type="text" onChange={(e)=>{
            setCategory(e.target.value)
        }} />
        Description 
        <input type="text" onChange={(e)=>{
            setDescription(e.target.value)
        }} />

        <button onClick={handelSubmit}> Submit </button>
    </div>
  )
}

export default Add

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from './Axios';

const Signup = () => {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSignup = async () => {
    if (!name || !password) {
      alert("Username and password are required");
      return;
    }

    const ob = { username: name, password };

    try {
      const res = await api.post("/register", ob);
      alert("User Registered Successfully");
      navigate("/");
    } catch (err) {
      alert(err?.response?.data?.detail || "Signup failed");
    }
  };

  return (
    <div>
      <h2>Signup Page</h2>
      <label>User Name</label>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <label>Password</label>
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleSignup} disabled={!name || !password}>
        Sign Up
      </button>
      <br />
      <Link to="/">Already have an account?</Link>
    </div>
  );
};

export default Signup;

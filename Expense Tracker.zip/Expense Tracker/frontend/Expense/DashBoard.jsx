import React from 'react'
import { useEffect,useState } from 'react'
import api from './Axios'
import { Link,useNavigate } from 'react-router-dom'


const DashBoard = () => {
    
    let [search,setSearch]=useState("")
    let [data,setData]=useState([])
    let [filtered,setFiltered]=useState([])
    let [max,setMax]=useState(0)
    let [min,setMin]=useState(0)
    let [total,setTotal]=useState(0)
    useEffect(()=>{
      let fetchData=async ()=>{
       let user=JSON.parse(localStorage.getItem('user'))
       if(!user){
            alert("User not present")
       }else{
           let d=await api.get(`/expenses/${user.id}`)
           let summaryRes = await api.get(`/expenses/summary/${user.id}`)
           let summary = summaryRes.data
           setData(d.data)
           setFiltered(d.data)
           setMax(summary.max)
           setMin(summary.min)
           setTotal(summary.total)
       }
      }

     fetchData()
   },[])
   
   useEffect(() => {
           handelSearch();
      }, [search]);
   
   let handelSearch=()=>{
       setFiltered(data.filter( (ele)=>{
              return ele.description.toLowerCase().includes(search.toLowerCase())
       } ) )
   }
  return (
    <div>
           <h3> Enter Desc to search </h3>
          <input type="text" value={search} onChange={(e)=>{
            setSearch(e.target.value)
          }}/>
            
          {
            filtered.map(ele=>{
                return <section>
                   <h3> Description {ele.description }</h3>
                   <h3> Amount {ele.amount }</h3>
                   <h3> category {ele.category}</h3>
                   <h3> Date {ele.date} </h3>
                </section>
            })
          }
           <h2> Max Spent:{max} </h2>
           <h2> Min Spent:{min} </h2>
           <h2> Total Spent:{total} </h2>

           <Link to="/add">Add Expanse</Link>
    </div>
  )
}

export default DashBoard

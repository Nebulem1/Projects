import React from 'react'
import Login from './Login'
import Signup from './Signup'
import DashBoard from './DashBoard'
import { BrowserRouter as BR ,Route,Routes} from 'react-router-dom'
import Add from "./Add"

const Main = () => {
  return (
    <div>
        <BR>
        <Routes>
         <Route path="/" element={<Login />} />
         <Route path="/signup" element={<Signup />} />
         <Route path="/DashBoard" element={<DashBoard />} />
         <Route path="/add" element={<Add/>}/>
        </Routes>    
        </BR>
    </div>
  )
}

export default Main

from fastapi import APIRouter,Depends
from DB.Database import get_db
from sqlalchemy.orm import Session
from Model.expense import ExpenseCreate,ExpenseOut
from Schema.user import Expense
from typing import List
from sqlalchemy import func

router=APIRouter()
@router.post("/add_expenses/{userid}")
def add_expenses(userid:int,expense:ExpenseCreate,db:Session=Depends(get_db)):
     expense_db=Expense(amount=expense.amount,
                        category=expense.category,
                        description=expense.description,
                        user_id=userid)
     db.add(expense_db)
     db.commit()

@router.get("/expenses/{user_id}", response_model=List[ExpenseOut])
def get_expenses(user_id: int, db: Session = Depends(get_db)):
    data = db.query(Expense).filter(Expense.user_id == user_id).all()    
    return data

@router.get("/expenses/summary/{user_id}")
def get_expense_summary(user_id: int, db: Session = Depends(get_db)):
    result = db.query(
        func.sum(Expense.amount),
        func.max(Expense.amount),
        func.min(Expense.amount)
    ).filter(Expense.user_id == user_id).first()

    return {
        "total": result[0],
        "max": result[1],
        "min": result[2]
    }
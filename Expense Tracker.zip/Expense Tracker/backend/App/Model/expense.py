from pydantic import BaseModel 
from datetime import datetime

class ExpenseCreate(BaseModel):
    amount:float
    category:str
    description:str 
    class Config:
        orm_mode = True

class ExpenseOut(BaseModel):
    amount:float 
    category:str 
    description:str 
    date:datetime
    class Config:  #agar kisi bhi pydantic object ko ye dege to jab Alchemy ORM ka object return larega to wo iske class ke according arrange ho jayega
                   #Only agar response_model diya ho to 
        orm_mode = True

class UserData(BaseModel):
      username:str 
      password:str
      
class UserOut(BaseModel):
    id:int 
    username:str 
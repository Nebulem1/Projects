from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from Core.config import setting
from Model.expense import UserData,UserOut
from DB.Database import get_db
from sqlalchemy.orm import Session
from Core.security import get_password_hash
from Schema.user import User

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def get_current_user(token: str = Depends(oauth2_scheme) , db:Session =Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, setting.SECRET_KEY, algorithms=[setting.ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = db.query(User).filter(User.username==username).first()
    if user is None:
        raise credentials_exception
    return user

@router.get("/users/me/")
async def read_users_me(UserLogin :User = Depends(get_current_user)):
    return UserOut(username=UserLogin.username,id=UserLogin.id)

@router.post("/register")
async def register_user(userData:UserData,db:Session=Depends(get_db)):  
    if not userData.username or not userData.password:
        raise HTTPException(status_code=400, detail="Email and password are required")
    user = db.query(User).filter(User.username == userData.username).first()
    if user:
        raise HTTPException(status_code=400, detail="Email already registered")
    user_db=User(username=userData.username,hashed_password=get_password_hash(userData.password))
    db.add(user_db)
    db.commit()
    db.refresh(user_db)
    return {"message": "User created successfully"}